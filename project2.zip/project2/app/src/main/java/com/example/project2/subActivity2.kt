package com.example.project2

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_sub.*
import kotlinx.android.synthetic.main.activity_sub2.*

class subActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub2)

        val data = mutableListOf(" -- 선택 -- ", "조건 if", "조건 when", "반복 for", "반복 while")
        val list_of_summary2 = arrayOf(" 설명"," [조건문]\n" +
                "    말 그대로 특정 조건에 따라 실행을 다르게 하고 싶을때 사용합니다. 흐름제어문이라고도 표현\n" +
                "    조건문에는 if, when 이 있으며\n" +
                "    조건문의 조건을 판단하기 위해서 비교연산자와 논리연산자를 사용\n" +
                "\n" +
                "    var chromosome = \"XX\"\n" +
                "\n" +
                "    if (chromosome == \"XX\") {\n" +
                "    println(\"여성\")\n" +
                "    } else if (chromosome == \"XY\") {\n" +
                "    println(\"남성\")\n" +
                "    } else {\n" +
                "    println(\"?????\")\n" +
                "    }", " when도 조건문 중의 하나\n" +
                "        화살표 연산자와 else를 조합하여 when절을 완성\n" +
                "\n" +
                "        Ex) when (chromosome) {\n" +
                "                \"XX\" -> {\n" +
                "                     println(\"여성\")\n" +
                "                }\n" +
                "                \"XY\" -> {\n" +
                "                    println(\"남성\")\n" +
                "                 }\n" +
                "                else -> {\n" +
                "                    println(\"?????\")\n" +
                "                }\n" +
                "            }",

                " 반복문은 코드를 반복시킬때 사용\n" +
                "    * 반복문에는 for과 while 2가지가 있습니다.\n" +
                "    * 이 둘의 큰 차이는 아래 비교와 같다\n" +
                "    * for 문은 특정횟수만큼 반복하는 것\n" +
                "    * while은 특정 조건이 만족할때까지 반복하는 것 \n" +
                        " for (범위) {\n" +
                "        실행코드 \n" +
                "    } 로 이루어져 있음.\n" +
                "    \n" +
                "    Ex) for (i in 1..5) {\n" +
                "            println(\"..($)i)\n" +
                "        } 의 결과는 1 2 3 4 5,\n" +
                "    \n" +
                "    for (i in 1 until 5) {\n" +
                "        println(\"until ($)i\")\n" +
                "    } 의 결과는 1 2 3 4,\n" +
                "    \n" +
                "    //downTo는 ..와 반대로 시작부터 끝까지 감소\n" +
                "    for (i in 5 downTo 1) {\n" +
                "        println(\"downTo ($)i\")\n" +
                "    } 의 결과는 5 4 3 2 1  ", " while(조건식) {\n" +
                "       // 실행코드\n" +
                "        }로 이루어져있다\n" +
                "     while은 특정 조건이 만족할 때까지 반복하는 것이므로\n" +
                "     for 문과는 달리 조건을 관리할 변수를 만들어야한다\n" +
                "     Ex)var index = 1\n" +
                "\n" +
                "     while (index < 5) {\n" +
                "     println(\"while $\")\n" +
                "     // 조건에 대한 관리를 잘못하면 무한반복에 빠져 메모리 이슈가 생깁니다.\n" +
                "     index += 1 // index = index + 1\n" +
                "     }의 결과는 1 2 3 4\n" +
                "\n" +
                "    do ~ while는 while문의 변형 형태\n" +
                "\n" +
                "    do {\n" +
                "       실행코드\n" +
                "    } while(조건식) 으로 이루어져 있다\n" +
                "\n" +
                "     while 문과의 차이점은 먼저 실행을하고 조건을 비교하여 다음에 다시 반복할지 여부를 정하기 때문에\n" +
                "     무조건 한번은 실행을 한다는 것\n [반복문 제어]\n" +
                "    break, continue를 사용하여 반복문을 제어\n" +
                "    break는 지정한 반복 횟수 혹은 조건이 끝나기전에 반복문에서 탈출을 가능하게 만듦\n" +
                "    continue는 반복은 유지하면 특정 차례만 뛰어넘을때 사용")

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, data)

        spinner.adapter = adapter

        spinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                summary2.text= list_of_summary2[p2]
            }
        }
        goBack.setOnClickListener {
            finish()
        }

    }
    override fun onStart() {
        super.onStart()
        Log.d("LifeCycle", "onStart : subActivity")
    }

    override fun onResume() {
        super.onResume()
        Log.d("LifeCycle", "onResume : subActivity2")
    }

    override fun onPause() {
        super.onPause()
        Log.d("LifeCycle", "onPause : subActivity2")
    }

    override fun onStop() {
        super.onStop()
        Log.d("LifeCycle", "onStop : subActivity2")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("LifeCycle", "onDestory : subActivity2")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                0 -> {
                    val returnMessage = data?.getStringExtra("ReturnMessage")
                    Toast.makeText(this, returnMessage, Toast.LENGTH_SHORT).show()
                }
            }

        }
    }
}