package com.example.project2

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_sub.*
import kotlinx.android.synthetic.main.activity_sub.spinner

class subActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub)
        Log.d("LifeCycle", "onCreate : subActivity")

        val data = mutableListOf(" -- 선택 -- ", "변수와 상수", "데이터 타입")
        val listOfSummary: Array<String> = arrayOf("설명 ", "변수는 var, 상수는 val이라는 예약어를 사용.\n" +
                "            var___ = \"~~~~\"  이 형태는 선언과 부여를 동시에 함.\n" +
                "            ex) var day: Sting, day = \"Saturday\"\n" +
                "            var age = 20\n" +
                "            val BloodType = \"O형\" ","변수는 컴퓨터의 메모리에 저장이되는데 이 변수에게 할당할 메모리 크기를 알아야하므로\n" +
                "            자료형을 이용하여 정의해야 한다.\n" +
                "            논리형\n" +
                "            Boolean - 참과 거짓의 값을 나타냄 true / false\n" +
                "            문자\n" +
                "            Char - 16bit | 한글자의 문자\n" +
                "            String - Char 여러글자의 문자\n" +
                "            https://kotlinlang.org/docs/reference/basic-types.html\n" +
                "            정수형\n" +
                "            Byte - 8bit | -128 ~ 127 (-2^7 ~ 2^7 -1)\n" +
                "            Short - 16bit | -32768 ~ 32767 (-2^15 ~ 2^15 -1)\n" +
                "            Int - 32bit | -2,147,483,648 ~ 2,147,483,647 (-2^31 ~ 2^31 -1)\n" +
                "            Long - 64bit | -9,223,372,036,854,775,808 ~ -9,223,372,036,854,775,807 (-2^63 ~ 2^63 -1)\n" +
                "            실수형\n" +
                "            Float - 32bit |\n" +
                "            Double - 64bit |\n" +
                "\n" +
                "            Ex)var isBoolen = true\n" +
                "            var isChar = 'a'\n" +
                "            var isInt = 123\n" +
                "            var isByte: Byte = 123\n")
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, data)

        spinner.adapter = adapter

        spinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                summary.text= listOfSummary[p2]
            }
        }


        goBackBtn.setOnClickListener {
            finish()
        }
    }
    override fun onStart() {
        super.onStart()
        Log.d("LifeCycle", "onStart : subActivity")
    }

    override fun onResume() {
        super.onResume()
        Log.d("LifeCycle", "onResume : subActivity")
    }

    override fun onPause() {
        super.onPause()
        Log.d("LifeCycle", "onPause : subActivity")
    }

    override fun onStop() {
        super.onStop()
        Log.d("LifeCycle", "onStop : subActivity")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("LifeCycle", "onDestory : subActivity")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                0 -> {
                    val returnMessage = data?.getStringExtra("ReturnMessage")
                    Toast.makeText(this, returnMessage, Toast.LENGTH_SHORT).show()
                }
            }

        }
    }
}