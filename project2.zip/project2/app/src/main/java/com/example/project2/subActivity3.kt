package com.example.project2

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_sub.*
import kotlinx.android.synthetic.main.activity_sub3.*

class subActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub3)
        val data = mutableListOf(" -- 선택 -- ", "컬렉션","배열")
        val listOfSummary3 = arrayOf(" [컬렉션은 크게 세가지 List, Map, Set 로 나뉨]",
                    "리스트는 List, mutableList.\n" +
                    "      List는 array처럼 공간의 제약이 있으면서 array와는 달리 값의 수정이 되지 않는 read-only이므로 사용할 일이 별로 없음\n" +
                    "     mutableList는 공간의 제약도 없고 값의 수정 및 삭제도 자유 " +
                    "Set은 중복을 허용하지 않으며 순서가 없는 list라 생각하면 편함\n" +
                    "      하지만 순서가 없기때문에 인덱스로 조회할 수 없음\n" +
                    "Ex)   var set = mutableSetOf<String>()\n" +
                    "    var set = mutableSetOf(\"A\", \"B\", \"C\", \"A\", \"D\")\n" +
                    "    println(set)\n" +
                    "    set.add(\"B\")\n" +
                    "    println(set)\n" +
                    "    set.remove(\"A\")\n" +
                    "    println(set)\n " +
                    "Map은 키와 값이 쌍을 이루어서 입력되는 컬렉션\n" +
                    "    key는 list의 index의 역할", "배열의 경우 여러 값을 담을 수 있지만 먼저 공간의 크기를 결정해두고 써야함\n" +
                    "      크기가 정해지면 중간에 추가 및 삭제를 할수 없음\n" ,
                    "     기본 타입 뒤에 Array를 붙여서 생성\n" +
                    "        \n" +
                    "     Ex) var intArray = IntArray(10)\n" +
                    "    var longArray = LongArray(10)\n" +
                    "    var byteArray = ByteArray(10)\n" +
                    "    var shortArray = ShortArray(10)\n" +
                    "    var floatArray = FloatArray(10)\n" +
                    "    var doubleArray = DoubleArray(10)\n" +
                    "    var charArray = CharArray(10) ")

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, data)

        spinner.adapter = adapter

        spinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                summary3.text= listOfSummary3[p2]
            }
        }
        goback2.setOnClickListener {
            finish()
        }
    }
    override fun onStart() {
        super.onStart()
        Log.d("LifeCycle", "onStart : subActivity3")
    }

    override fun onResume() {
        super.onResume()
        Log.d("LifeCycle", "onResume : subActivity3")
    }

    override fun onPause() {
        super.onPause()
        Log.d("LifeCycle", "onPause :subActivity3")
    }

    override fun onStop() {
        super.onStop()
        Log.d("LifeCycle", "onStop : subActivity3")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("LifeCycle", "onDestory : subActivity3")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                0 -> {
                    val returnMessage = data?.getStringExtra("ReturnMessage")
                    Toast.makeText(this, returnMessage, Toast.LENGTH_SHORT).show()
                }
            }

        }
    }
}