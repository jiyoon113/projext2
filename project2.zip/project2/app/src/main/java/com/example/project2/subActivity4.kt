package com.example.project2

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_sub3.*
import kotlinx.android.synthetic.main.activity_sub4.*

class subActivity4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub4)
        goBack3.setOnClickListener {
            finish()
        }

    }
    override fun onStart() {
        super.onStart()
        Log.d("LifeCycle", "onStart : subActivity4")
    }

    override fun onResume() {
        super.onResume()
        Log.d("LifeCycle", "onResume : subActivity4")
    }

    override fun onPause() {
        super.onPause()
        Log.d("LifeCycle", "onPause : subActivity4")
    }

    override fun onStop() {
        super.onStop()
        Log.d("LifeCycle", "onStop : subActivity4")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("LifeCycle", "onDestory : subActivity4")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                0 -> {
                    val returnMessage = data?.getStringExtra("ReturnMessage")
                    Toast.makeText(this, returnMessage, Toast.LENGTH_SHORT).show()
                }
            }

        }
    }
}