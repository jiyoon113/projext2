package com.example.project2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d("LifeStyle", "onCreate: ")
        Btn1.setOnClickListener{
            val intent = Intent(this, subActivity::class.java)
            startActivity(intent)
        }
        Btn2.setOnClickListener{
            val intent = Intent(this, subActivity2::class.java)
            startActivity(intent)
        }
        Btn3.setOnClickListener{
            val intent = Intent(this, subActivity3::class.java)
            startActivity(intent)
        }
        Btn4.setOnClickListener{
            val intent = Intent(this, subActivity4::class.java)
            startActivity(intent)
        }
    }
    override fun onStart() {
        super.onStart()
        Log.d("LifeStyles", "onStart :")

    }
    override fun onResume() {
        super.onResume()
        Log.d("LifeStyles", "onResume : ")

    }
    override fun onPause() {
        super.onPause()
        Log.d("LifeStyles", "onPause : ")

    }
    override fun onStop() {
        super.onStop()
        Log.d("LifeStyles", "onStop : ")
    }
    override fun onRestart() {
        super.onRestart()
        Log.d("LifeStyles", "onRestart : ")
    }
    override fun onDestroy() {
        super.onDestroy()
        Log.d("LifeStyles", "onDestroy : ")
    }
}
