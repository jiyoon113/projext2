package com.example.myactivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d("LifeCycle", "onCreate : 액티비의 생성, 액티비티에서 딱 한번만 호출됨.")

        clickBtn.setOnClickListener{
            val intent = Intent(this, SubActivity::class.java)
            startActivity(intent)
        }

    }
    override fun onStart() {
        super.onStart()
        Log.d("LifeStyles", "onStart : 액티비티의 시작, 이 때 화면이 그려지기 시작")

    }
    override fun onResume() {
        super.onResume()
        Log.d("LifeStyles", "onResume : 액티비티가 실행되고 있는 상태")

    }
    override fun onPause() {
        super.onPause()
        Log.d("LifeStyles", "onPause : 액티비가 일시중지, 조금이라도 1dp라도 다른 액티비티에 가려져도 발생")

    }
    override fun onStop() {
        super.onStop()
        Log.d("LifeStyles", "onStop : 액티비티가 사용자에게 더이상 표시되지 않으면 발생(앱이 사용자에게 보이지 않은 동안 앱은 필요 ㄴㄴ")

    }
    override fun onRestart() {
        super.onRestart()
        Log.d("LifeStyles", "onRestart")
    }
    override fun onDestroy() {
        super.onDestroy()
        Log.d("LifeStyles", "onDestroy : 액티비티가 사라지기 전에 발생")
    }
}
